
import { TonClient } from '@tonclient/core';
import { expect } from 'chai';
import { createClient } from './utils/client';
const fs = require("fs");

describe("debot test", () => {
  let client: TonClient;

  before(async () => {
    client = createClient()
  });

  it("test", async () => {
    
  })
})

