import { TonClient } from '@tonclient/core';
import { expect } from 'chai';
import { createClient } from './utils/client';
import pkgSafeMultisigWallet from '../ton-packages/SafeMultisigWallet.package'
import TonContract from './utils/ton-contract'
import pkgTest from "../ton-packages/Test.package";
import { utf8ToHex } from './utils/convert';

//import pkg from '/home/nikolai/TestC/build/Test.abi.json'
const fs = require('fs')
describe('debot test', () => {
  let client: TonClient
  let smcSafeMultisigWallet: TonContract
  let smcTest: TonContract

  before(async () => {
    client = createClient()
    smcSafeMultisigWallet = new TonContract({
      client,
      name: 'SafeMultisigWallet',
      tonPackage: pkgSafeMultisigWallet,
      address: process.env.MULTISIG_ADDRESS,
      keys: {
        public: process.env.MULTISIG_PUBKEY,
        secret: process.env.MULTISIG_SECRET,
      },
    })
    // console.log(0, smcSafeMultisigWallet);
  })

  it('deploy test', async () => {
  
    const keys = await client.crypto.generate_random_sign_keys()
    smcTest = new TonContract({
      client,
      name: 'Test',
      tonPackage: pkgTest,
      keys,
    })

    await smcTest.calcAddress();
    console.log(0,smcTest );

    console.log('Test address: ', smcTest.address)

    await smcSafeMultisigWallet.call({
      functionName: 'sendTransaction',
      input: {
        dest: smcTest.address,
        value: 2e9,
        bounce: false,
        flags: 2,
        payload: '',
      },
    })

    await smcTest.deploy();
    
  })
})